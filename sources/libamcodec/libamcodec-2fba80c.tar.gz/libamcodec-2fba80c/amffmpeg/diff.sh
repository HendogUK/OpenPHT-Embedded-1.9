git diff {62c3f83f1968ed583625b84e528b16fe2dfe6c36,HEAD} . >changes.diff
