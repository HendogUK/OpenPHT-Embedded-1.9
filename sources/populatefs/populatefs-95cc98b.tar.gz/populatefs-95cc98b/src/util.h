#ifndef __util__h__
#define __util__h__

extern unsigned long oct2dec(unsigned long int value);

#endif
