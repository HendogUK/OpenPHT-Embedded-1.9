#ifndef __mod_file__h__
#define __mod_file__h__
#include <sys/types.h>

extern void addFilespec(FILE *fd, int squash_uids, int squash_perms);

#endif
