/*
 * Do not edit!  Automatically generated file:
 *   from: NetBSD: shlib_version,v 1.41 2015/11/22 04:56:00 kamil Exp 
 *   by  : NetBSD: genfileioh.awk,v 1.2 2008/05/02 11:13:02 martin Exp 
 */

#define CURSES_LIB_MAJOR 7
#define CURSES_LIB_MINOR 0
