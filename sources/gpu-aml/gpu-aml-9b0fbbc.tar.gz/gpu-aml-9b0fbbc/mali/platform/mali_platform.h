/*
 * mali_platform.h
 *
 *  Created on: Nov 8, 2013
 *      Author: amlogic
 */

#include <linux/kernel.h>
#ifndef MALI_PLATFORM_H_
#define MALI_PLATFORM_H_

extern u32 mali_gp_reset_fail;
extern u32 mali_core_timeout;

#endif /* MALI_PLATFORM_H_ */
