.. cmake-module:: ../../Modules/FindosgTerrain.cmake
