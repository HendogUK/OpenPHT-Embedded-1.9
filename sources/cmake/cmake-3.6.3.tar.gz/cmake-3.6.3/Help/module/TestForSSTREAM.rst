.. cmake-module:: ../../Modules/TestForSSTREAM.cmake
