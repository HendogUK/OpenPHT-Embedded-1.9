.. cmake-module:: ../../Modules/SquishTestScript.cmake
