.. cmake-module:: ../../Modules/CPackCygwin.cmake
