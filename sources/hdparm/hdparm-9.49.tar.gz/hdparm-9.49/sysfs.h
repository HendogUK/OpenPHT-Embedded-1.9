int sysfs_get_start_lba (dev_t dev, __u64 *start_lba);
