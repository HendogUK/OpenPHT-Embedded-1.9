AML DTB Tools
====

Comprises of a splitter and builder of AmLogic's multi-dtb formats.

The format is deduced from the [AmLogic u-boot code](https://github.com/codesnake/uboot-amlogic/blob/master/common/aml_dt.c)

The dtbTool is based on dtbTool source from the CyanogenMod project.
