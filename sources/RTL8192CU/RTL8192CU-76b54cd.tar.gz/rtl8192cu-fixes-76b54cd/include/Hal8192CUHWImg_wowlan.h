/******************************************************************************
 *
 * Copyright(c) 2007 - 2011 Realtek Corporation. All rights reserved.
 *                                        
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110, USA
 *
 *
 ******************************************************************************/
#ifndef __INC_HAL8192CU_FW_IMG_WOWLAN_H
#define __INC_HAL8192CU_FW_IMG_WOWLAN_H

/*Created on  2011/11/ 8, 14:15*/


#define TSMCWWImgArrayLength 13458
extern u8 Rtl8192CUFwTSMCWWImgArray[TSMCWWImgArrayLength];
#define UMCACutWWImgArrayLength 13458
extern u8 Rtl8192CUFwUMCACutWWImgArray[UMCACutWWImgArrayLength];
#define UMCBCutWWImgArrayLength 13446
extern u8 Rtl8192CUFwUMCBCutWWImgArray[UMCBCutWWImgArrayLength];

#endif //__INC_HAL8192CU_FW_IMG_WOWLAN_H

