#ifndef _SSV_VERSION_H_
#define _SSV_VERSION_H_

static u32 ssv_root_version = 13940;

#define SSV_ROOT_URl "http://192.168.15.30/svn/software/project/release/android/box/aml_s905/6051.Q0.1009.15.e10104/ssv6xxx"
#define COMPILERHOST "icommsemi"
#define COMPILERDATE "12-02-2016-11:51:23"
#define COMPILEROS "linux"
#define COMPILEROSARCH "x86_64-linux-gnu-thread-multi"

#endif

